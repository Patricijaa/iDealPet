import { memo } from 'react';
import type { FC } from 'react';

import resets from '../_resets.module.css';
import classes from './Krepselis.module.css';

interface Props {
  className?: string;
}
/* @figmaId 207:102 */
export const Krepselis: FC<Props> = memo(function Krepselis(props = {}) {
  return (
    <div className={`${resets.storybrainResets} ${classes.root}`}>
      <div className={classes.rectangle24}></div>
      <div className={classes.rectangle4}></div>
      <div className={classes.baigti}>Apmokėti</div>
      <div className={classes.rectangle42}></div>
      <div className={classes.baigti2}>Tęsti apsipirkimą</div>
      <div className={classes.image22}></div>
      <div className={classes.rectangle5}></div>
      <div className={classes.image12}></div>
      <div className={classes.prisijungta}>Prisijungta</div>
      <div className={classes.rectangle43}></div>
      <div className={classes.image25}></div>
      <div className={classes.rectangle27}></div>
      <div className={classes.rectangle25}></div>
      <div className={classes.gyvunas}>Gyvūnas</div>
      <div className={classes.nr}>Nr.</div>
      <div className={classes.kaina}>Kaina</div>
      <div className={classes.kiekis}>Kiekis</div>
      <div className={classes.isViso}>Iš viso</div>
      <div className={classes.fonas}></div>
      <div className={classes.image252}></div>
      <div className={classes._1500}>1500</div>
      <div className={classes._1}>1</div>
      <div className={classes._12}>1.</div>
      <div className={classes._15002}>1500</div>
    </div>
  );
});
